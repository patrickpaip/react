import React from 'react';
import  Dashboard from './container/dashboard';
import  Login from './container/login';

class App extends React.Component{

  render(){
    return (
      <div>
          <Dashboard/>
      </div>
    )
  }
}

export default App;
