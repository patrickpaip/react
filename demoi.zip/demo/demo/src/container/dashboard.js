import React from 'react';
import CreditCardHolder from '../pages/creditCards/CreditCardHolder';

class Dashboard extends React.Component{

  render(){
    return (
      <div>
          <CreditCardHolder/>
      </div>
    )
  }
}

export default Dashboard;