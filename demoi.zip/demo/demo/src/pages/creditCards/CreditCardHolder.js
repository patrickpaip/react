import React from 'react';
import TableComponent from '../../components/creditCard/tableComponent';
import FormComponent from '../../components/creditCard/formComponent';
import ViewComponent from '../../components/creditCard/viewComponent';


class CreditCardHolder extends React.Component{
  state={
      "viewData" : {
        customerID : '',
        customerName: '',
      },
      "formData":{
        customerID: "xys",
        customerName : "xys",
        customerAddress:"dfg"
      },
      tabledata:  [
        {
            customerID : '00001',
            customerName: 'Shardul',
            customerAddress : 'XYZ',
            lockStatus : true,
            applicationID : "1234"
         },
        {
          customerID : '00002',
          customerName: 'Prathik',
          customerAddress : 'XYZ',
          lockStatus : false
      },{
          customerID : '00003',
          customerName: 'Kartik',
          customerAddress : 'XYZ',
          lockStatus : false
      },{
          customerID : '00004',
          customerName: 'Shubham',
          customerAddress : 'XYZ',
          lockStatus : false
      }
  
    ]
  }

  viewHandler =(data)=>{
    this.setState({
      viewData : data
    })
}

  onFormDataChangeHandler = (event) =>{
       this.setState({
         formData : {
           ...this.state.formData,
           [event.target.name] : event.target.value
         }
       })
  }
  onFormSubmitHandler = () =>{
      let tableData= [...this.state.tabledata];
      tableData.push(this.state.formData)
      this.setState({
        tabledata : [
          ...tableData
        ]
      })
}

  render(){
    return (
      <div>
      <div>
            <TableComponent  tabledata={this.state.tabledata} viewHandler={this.viewHandler}/>
      </div>
      <div style={{display:'flex'}}>
            <FormComponent formData={this.state.formData} onFormDataChangeHandler={this.onFormDataChangeHandler} onFormSubmitHandler={this.onFormSubmitHandler}/>
            <ViewComponent customerName={this.state.viewData.customerName} customerID={this.state.viewData.customerID}/>
      </div>
      </div>
    )
  }
}

export default CreditCardHolder;