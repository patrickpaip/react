import React from 'react';
import ReactTable from "react-table";
import "react-table/react-table.css";
import DashboardIcon from '@material-ui/icons/Dashboard';
import LockClosedIcon from '@material-ui/icons/Lock';
import LockOpenIcon from '@material-ui/icons/LockOpen';
import { Tooltip } from '@material-ui/core';

class TableComponent extends React.Component{
 


  
    columns=[
      {
          Header: "",
          accessor: "lockStatus",
          Cell : row =>(
              <div>
             {(row.original.lockStatus)?<Tooltip title="Unlock">
              <LockClosedIcon/>
              </Tooltip>:
              <Tooltip title="Lock">
              <LockOpenIcon/>
              </Tooltip>} 
          </div>
          )
        },
  
      {
          Header: "Customer ID",
          accessor: "customerID"
        },
        {
          Header: "Customer Name",
          accessor: "customerName"
        },
        {
          Header: "Customer Address",
          accessor: "customerAddress"
        },
        {
          Header: "Actions",
          accessor: "customerName",
          Cell : row =>(
              <div>
                  <Tooltip title="View Info">
                  <DashboardIcon onClick={()=>this.props.viewHandler(row.original)}/>
                  </Tooltip>
              </div>
          )
        }
      ]
   


  render(){
    return (
      <div>
          <ReactTable
        data={this.props.tabledata}
        columns={this.columns}
        defaultPageSize={5}
        className="-striped -highlight"
          
          />
      </div>
    )
  }
}

export default TableComponent;