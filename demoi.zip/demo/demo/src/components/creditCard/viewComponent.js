import React from 'react';

function ViewComponent(props){
    return (
      <div>
          <div>
               {props.customerID} 
          </div>
          <div>
               {props.customerName} 
          </div>
      </div>
    )
}

export default ViewComponent;