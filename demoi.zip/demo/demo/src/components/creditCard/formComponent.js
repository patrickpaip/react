import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import { Button } from '@material-ui/core';

const useStyles = makeStyles(theme => ({
    container: {
      display: 'flex',
      flexWrap: 'wrap',
    },
    textField: {
      marginLeft: theme.spacing(1),
      marginRight: theme.spacing(1),
    },
    dense: {
      marginTop: theme.spacing(2),
    },
    menu: {
      width: 200,
    },
  }));

function FormComponent(props){
 
    const classes = useStyles();
    return (
      <React.Fragment>
           <TextField
        id="outlined-with-placeholder"
        label="ID"
        name= "customerID"
        placeholder="Placeholder"
        className={classes.textField}
        margin="normal"
        onChange={props.onFormDataChangeHandler}
        value={props.formData.customerID}
        variant="outlined"
      />
       <TextField
        id="outlined-with-placeholder"
        label="Name"
        name= "customerName"
        placeholder="Placeholder"
        className={classes.textField}
        margin="normal"
        onChange={props.onFormDataChangeHandler}
        value={props.formData.customerName}
        variant="outlined"
      />
       <TextField
        id="outlined-with-placeholder"
        label="Address"
        name= "customerAddress"
        placeholder="Placeholder"
        value={props.formData.customerAddress}
        className={classes.textField}
        margin="normal"
        onChange={props.onFormDataChangeHandler}
        variant="outlined"
      />
     <Button onClick={()=>props.onFormSubmitHandler()}>Add To Table</Button>
      
    </React.Fragment>
    )
}

export default FormComponent;