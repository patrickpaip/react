import React, {Component} from 'react';
import DashboardContainer from './container/dashboardContainer';

class App extends Component{
  
  render(){
    return(
      <div>
         <DashboardContainer/>
      </div>
    );
  }
}
export default App;
