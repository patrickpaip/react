import React, {Component} from 'react';
import TableComponent from '../../components/creditComponents/tableComponent';
import FormComponent from '../../components/creditComponents/formComponent';
import ViewComponent from '../../components/creditComponents/viewComponent';

class CreditCardPage extends Component{
    state={
        viewData : {
            "customerID" : "sdsd",
            "customerName" : "sdsd"
        },
        formData: {
            "customerID" : "sdd",
            "customerName" : "sds",
            "customerAddress" : "sdsd",
            "applicationStatus" : false,
        },
        tableContent : [
            {
                "customerID" : "0001",
                "customerName" : "Batman",
                "customerAddress" : "Gotham",
                "applicationStatus" : true,
            },
            {
              "customerID" : "0002",
              "customerName" : "Superman",
              "customerAddress" : "Krypton",
              "applicationStatus" : false,
          },
          {
              "customerID" : "0003",
              "customerName" : "Shakthiman",
              "customerAddress" : "Mumbai",
              "applicationStatus" : true,
          }
        ]
    }

    viewHandler= (data)=>{
       this.setState({
           viewData : data
       })
    }

    onFormChangeHandler =(event)=>{
            this.setState({
                formData : {
                    ...this.state.formData,
                    [event.target.name] : event.target.value
                }
            })
    }
    onSubmitHandler =()=>{
        console.log("Im Called")
        let tableData=[...this.state.tableContent];
        tableData.push(this.state.formData)
        this.setState({
            tableContent: tableData
        })
    }
  render(){
    return(
      <div>
         <div>
              <TableComponent tableContent={this.state.tableContent} viewHandler={this.viewHandler}/>
         </div>
         <div style={{display:'flex'}}>
               <div>
                    <FormComponent formData={this.state.formData} onFormChangeHandler={this.onFormChangeHandler} onSubmitHandler={this.onSubmitHandler}/>
               </div>
               <div>
                    <ViewComponent viewData={this.state.viewData}/>
               </div>
         </div>
      </div>
    );
  }
}
export default CreditCardPage;