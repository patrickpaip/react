import React, {Component} from 'react';
import ReactTable from "react-table";
import "react-table/react-table.css";
import ViewIcon from '@material-ui/icons/PlayForWork'
import { Tooltip } from '@material-ui/core';

class TableComponent extends Component{
    
  columns= [
      {
        Header: "Customer ID",
        accessor: "customerID"
      },
      {
        Header: "Customer Name",
        accessor: "customerName"
      },
      {
        Header: "Customer Address",
        accessor: "customerAddress"
      },
      {
        Header: "Actions",
        accessor: "customerAddress",
        filterable : false,
        Cell : row => (
        <Tooltip title="View Details">
           <ViewIcon onClick={()=>this.props.viewHandler(row.original)}/>
           </Tooltip>
        )
      }
  ]

  render(){
    return(
      <div>
          <ReactTable
            data={this.props.tableContent}
            columns={this.columns}
            filterable
            defaultPageSize={5}
          className="-striped -highlight"
          />
      </div>
    );
  }
}
export default TableComponent;