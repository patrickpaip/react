––
import React, {Component} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import { Button } from '@material-ui/core';

const useStyles = makeStyles(theme => ({
    container: {
      display: 'flex',
      flexWrap: 'wrap',
    },
    textField: {
      marginLeft: theme.spacing(1),
      marginRight: theme.spacing(1),
    },
    dense: {
      marginTop: theme.spacing(2),
    },
    menu: {
      width: 200,
    },
  }));

function FormComponent(props){
    const classes = useStyles();
    return(
      <div>
            <TextField
        id="outlined-with-placeholder"
        label="With placeholder"
        name = "customerID"
        placeholder="Placeholder"
        value={props.formData.customerID}
        className={classes.textField}
        onChange={props.onFormChangeHandler}
        margin="normal"
        variant="outlined"
      />
       <TextField
        id="outlined-with-placeholder"
        label="With placeholder"
        name="customerName"
        placeholder="Placeholder"
        onChange={props.onFormChangeHandler}
        value={props.formData.customerName}
        className={classes.textField}
        margin="normal"
        variant="outlined"
      />
       <TextField
        id="outlined-with-placeholder"
        name="customerAddress"
        label="With placeholder"
        placeholder="Placeholder"
        onChange={props.onFormChangeHandler}
        value={props.formData.customerAddress}
        className={classes.textField}
        margin="normal"
        variant="outlined"
      />
     <Button onClick={()=>props.onSubmitHandler()}>Click Me</Button>
      </div>
    );

}
export default FormComponent;