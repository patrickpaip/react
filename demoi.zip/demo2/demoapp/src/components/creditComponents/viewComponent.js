import React, {Component} from 'react';

function ViewComponent(props){

    return(
      <div>
          <div>{props.viewData.customerID}</div>
          <div>{props.viewData.customerName}</div>
      </div>
    );

}
export default ViewComponent;