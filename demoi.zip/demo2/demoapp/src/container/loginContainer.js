import React, {Component} from 'react';

class LoginContainer extends Component{
  render(){
    return(
      <div>
          LoginContainer
      </div>
    );
  }
}
export default LoginContainer;
