import React, {Component} from 'react';
import CreditCardPage from '../pages/creditCard/creditCardPage';

class DashboardContainer extends Component{
  state={
    
  }
  render(){
    return(
      <div>
          <CreditCardPage/>
      </div>
    );
  }
}
export default DashboardContainer;
